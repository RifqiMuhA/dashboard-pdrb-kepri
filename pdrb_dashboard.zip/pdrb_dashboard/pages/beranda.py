import dash
from dash import html, dcc, callback, Output, Input
import plotly.express as px

from utils.data_loader import DATA, PROVINSI_LABEL, get_years_list
from utils.analysis import hitung_laju_pertumbuhan, hitung_pdrb_perkapita
from utils.components import kpi_card, card, page_heading
from theme import COLORS

dash.register_page(__name__, path="/", name="Beranda")

years = get_years_list()
latest_year = max(years)

layout = html.Div(
    [
        page_heading("Beranda", "Ringkasan kondisi ekonomi wilayah"),
        html.Div(id="kpi-row", className="filter-row"),
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "20px"},
            children=[
                card("PDRB ADHB Tertinggi & Terendah per Kab/Kota (Tahun Terbaru)", dcc.Graph(id="graf-pdrb-highlight")),
                card("Laju Pertumbuhan Ekonomi per Kab/Kota (Tahun Terbaru)", dcc.Graph(id="graf-growth-highlight")),
            ],
        ),
    ]
)


@callback(Output("kpi-row", "children"), Input("kpi-row", "id"))
def update_kpi(_):
    df_pdrb = DATA["pdrb"]
    df_penduduk = DATA["penduduk"]

    total_prov = df_pdrb[(df_pdrb["kab_kota"] == PROVINSI_LABEL) & (df_pdrb["tahun"] == latest_year)]["adhb"].sum()
    growth_df = hitung_laju_pertumbuhan(df_pdrb)
    growth_prov = growth_df[(growth_df["kab_kota"] == PROVINSI_LABEL) & (growth_df["tahun"] == latest_year)]
    growth_val = growth_prov["laju_pertumbuhan"].iloc[0] if not growth_prov.empty else None

    perkapita_df = hitung_pdrb_perkapita(df_pdrb, df_penduduk)
    perkapita_prov = perkapita_df[(perkapita_df["kab_kota"] == PROVINSI_LABEL) & (perkapita_df["tahun"] == latest_year)]
    perkapita_val = perkapita_prov["pdrb_perkapita"].iloc[0] if not perkapita_prov.empty else None

    penduduk_prov = df_penduduk[(df_penduduk["kab_kota"] == PROVINSI_LABEL) & (df_penduduk["tahun"] == latest_year)]
    penduduk_val = penduduk_prov["jumlah_penduduk"].iloc[0] if not penduduk_prov.empty else None

    return [
        kpi_card(f"PDRB ADHB {PROVINSI_LABEL} ({latest_year})", f"Rp {total_prov:,.0f} jt"),
        kpi_card(f"Laju Pertumbuhan ({latest_year})", f"{growth_val:.2f}%" if growth_val is not None else "-"),
        kpi_card("PDRB Perkapita", f"Rp {perkapita_val:,.2f} jt/jiwa" if perkapita_val is not None else "-"),
        kpi_card("Jumlah Penduduk", f"{penduduk_val:,.0f} jiwa" if penduduk_val is not None else "-"),
    ]


@callback(Output("graf-pdrb-highlight", "figure"), Input("kpi-row", "id"))
def update_pdrb_highlight(_):
    df = DATA["pdrb"]
    sub = df[(df["kab_kota"] != PROVINSI_LABEL) & (df["tahun"] == latest_year)]
    sub = sub.groupby("kab_kota", as_index=False)["adhb"].sum().sort_values("adhb", ascending=True)
    colors = [COLORS["accent"] if v == sub["adhb"].max() or v == sub["adhb"].min() else COLORS["primary"] for v in sub["adhb"]]
    fig = px.bar(sub, x="adhb", y="kab_kota", orientation="h", labels={"adhb": "PDRB ADHB (juta Rp)", "kab_kota": ""})
    fig.update_traces(marker_color=colors)
    return fig


@callback(Output("graf-growth-highlight", "figure"), Input("kpi-row", "id"))
def update_growth_highlight(_):
    growth_df = hitung_laju_pertumbuhan(DATA["pdrb"])
    sub = growth_df[(growth_df["kab_kota"] != PROVINSI_LABEL) & (growth_df["tahun"] == latest_year)].sort_values(
        "laju_pertumbuhan", ascending=True
    )
    colors = [
        COLORS["accent"] if v == sub["laju_pertumbuhan"].max() or v == sub["laju_pertumbuhan"].min() else COLORS["primary"]
        for v in sub["laju_pertumbuhan"]
    ]
    fig = px.bar(
        sub, x="laju_pertumbuhan", y="kab_kota", orientation="h",
        labels={"laju_pertumbuhan": "Laju Pertumbuhan (%)", "kab_kota": ""},
    )
    fig.update_traces(marker_color=colors)
    return fig
