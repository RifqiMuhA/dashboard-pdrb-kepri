import dash
from dash import html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go

from utils.data_loader import DATA, PROVINSI_LABEL, get_kab_kota_list, get_years_list
from utils.analysis import (
    hitung_pdrb_perkapita,
    hitung_williamson_series,
    hitung_bonet,
    hitung_shift_share,
    hitung_lq_matrix,
    hitung_tipologi_klassen,
    get_category_color_map,
)
from utils.components import card, page_heading
from theme import COLORS, REFERENCE_LINE_STYLE

dash.register_page(__name__, path="/wilayah", name="Analisis Antar Wilayah")

kab_kota_list = get_kab_kota_list()
years = get_years_list()

layout = html.Div(
    [
        page_heading("Analisis Antar Wilayah", "Indeks Williamson, Indeks Bonet, Shift Share, LQ, dan Tipologi Klassen"),
        dcc.Tabs(
            id="wilayah-tabs",
            className="custom-tabs",
            value="williamson",
            children=[
                dcc.Tab(label="Indeks Williamson", value="williamson", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Indeks Bonet", value="bonet", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Shift Share", value="shiftshare", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="LQ", value="lq", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Tipologi Klassen", value="klassen", className="tab", selected_className="tab--selected"),
            ],
        ),
        html.Div(id="wilayah-content", style={"marginTop": "20px"}),
    ]
)


@callback(Output("wilayah-content", "children"), Input("wilayah-tabs", "value"))
def render_tab(tab):
    if tab == "williamson":
        return card("Tren Indeks Williamson", dcc.Graph(id="graf-williamson"))
    elif tab == "bonet":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Tahun", className="filter-label"),
                                dcc.Dropdown(id="bonet-tahun", options=years, value=max(years), clearable=False),
                            ],
                        )
                    ],
                ),
                card("Indeks Bonet per Kab/Kota", dcc.Graph(id="graf-bonet")),
            ]
        )
    elif tab == "shiftshare":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Kab/Kota", className="filter-label"),
                                dcc.Dropdown(id="ss-kk", options=kab_kota_list, value=kab_kota_list[0], clearable=False),
                            ],
                        )
                    ],
                ),
                card("Komponen Shift Share per Lapangan Usaha", dcc.Graph(id="graf-shiftshare")),
            ]
        )
    elif tab == "lq":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Tahun", className="filter-label"),
                                dcc.Dropdown(id="lq-tahun", options=years, value=max(years), clearable=False),
                            ],
                        )
                    ],
                ),
                card("Heatmap LQ (Lapangan Usaha x Kab/Kota)", dcc.Graph(id="graf-lq")),
            ]
        )
    elif tab == "klassen":
        return card("Tipologi Klassen (rata-rata seluruh periode data)", dcc.Graph(id="graf-klassen"))
    return html.Div()


@callback(Output("graf-williamson", "figure"), Input("wilayah-tabs", "value"))
def update_williamson(_):
    df_perkapita = hitung_pdrb_perkapita(DATA["pdrb"], DATA["penduduk"])
    df_perkapita_kk = df_perkapita[df_perkapita["kab_kota"] != PROVINSI_LABEL]
    df_penduduk_kk = DATA["penduduk"][DATA["penduduk"]["kab_kota"] != PROVINSI_LABEL]
    result = hitung_williamson_series(df_perkapita_kk, df_penduduk_kk)
    fig = px.line(result, x="tahun", y="indeks_williamson", markers=True)
    fig.update_traces(line_color=COLORS["primary"])
    fig.update_layout(yaxis_title="Indeks Williamson (0-1)", yaxis_range=[0, 1])
    return fig


@callback(Output("graf-bonet", "figure"), Input("bonet-tahun", "value"))
def update_bonet(tahun):
    df_perkapita = hitung_pdrb_perkapita(DATA["pdrb"], DATA["penduduk"])
    df_bonet = hitung_bonet(df_perkapita, tahun, PROVINSI_LABEL).sort_values("indeks_bonet")
    fig = px.bar(df_bonet, x="indeks_bonet", y="kab_kota", orientation="h")
    fig.update_traces(marker_color=COLORS["primary"])
    fig.update_layout(xaxis_title="Indeks Bonet (deviasi terhadap provinsi)")
    return fig


@callback(Output("graf-shiftshare", "figure"), Input("ss-kk", "value"))
def update_shiftshare(kk):
    years_avail = sorted(DATA["pdrb"]["tahun"].unique())
    df_ss = hitung_shift_share(DATA["pdrb"], kk, PROVINSI_LABEL, years_avail[0], years_avail[-1])
    fig = go.Figure()
    fig.add_bar(x=df_ss["lapangan_usaha"], y=df_ss["regional_share"], name="Regional Share", marker_color=COLORS["primary"])
    fig.add_bar(x=df_ss["lapangan_usaha"], y=df_ss["proportional_shift"], name="Proportional Shift", marker_color=COLORS["accent"])
    fig.add_bar(x=df_ss["lapangan_usaha"], y=df_ss["differential_shift"], name="Differential Shift", marker_color=COLORS["primary_light"])
    fig.update_layout(barmode="relative", yaxis_title="Nilai Shift Share")
    return fig


@callback(Output("graf-lq", "figure"), Input("lq-tahun", "value"))
def update_lq(tahun):
    df_lq = hitung_lq_matrix(DATA["pdrb"], PROVINSI_LABEL, tahun)
    pivot = df_lq.pivot(index="lapangan_usaha", columns="kab_kota", values="lq")
    fig = px.imshow(
        pivot, text_auto=".2f", aspect="auto",
        color_continuous_scale=[[0, COLORS["gray_light"]], [0.5, COLORS["primary_light"]], [1, COLORS["primary_dark"]]],
        labels=dict(color="LQ"),
    )
    return fig


@callback(Output("graf-klassen", "figure"), Input("wilayah-tabs", "value"))
def update_klassen(_):
    years_avail = sorted(DATA["pdrb"]["tahun"].unique())
    df_klassen = hitung_tipologi_klassen(DATA["pdrb"], DATA["penduduk"], PROVINSI_LABEL, years_avail[0], years_avail[-1])
    color_map = get_category_color_map(df_klassen["kuadran"].unique().tolist())
    fig = px.scatter(
        df_klassen, x="pdrb_perkapita", y="laju_pertumbuhan", color="kuadran", text="kab_kota",
        color_discrete_map=color_map,
    )
    fig.update_traces(textposition="top center", marker=dict(size=12))
    ref_perkapita = df_klassen.attrs.get("ref_perkapita")
    ref_growth = df_klassen.attrs.get("ref_growth")
    if ref_perkapita is not None:
        fig.add_vline(x=ref_perkapita, line=REFERENCE_LINE_STYLE)
    if ref_growth is not None:
        fig.add_hline(y=ref_growth, line=REFERENCE_LINE_STYLE)
    fig.update_layout(xaxis_title="Rata-rata PDRB Perkapita", yaxis_title="Rata-rata Laju Pertumbuhan (%)")
    return fig
