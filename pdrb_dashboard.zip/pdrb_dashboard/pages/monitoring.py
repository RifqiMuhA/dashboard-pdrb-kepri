import dash
from dash import html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go

from utils.data_loader import DATA, PROVINSI_LABEL, get_kab_kota_list, get_years_list
from utils.analysis import (
    hitung_laju_pertumbuhan,
    hitung_kontribusi,
    hitung_pdrb_perkapita,
    hitung_sumber_pertumbuhan,
    hitung_indeks_implisit,
    get_category_color_map,
)
from utils.components import card, page_heading
from theme import COLORS, REFERENCE_LINE_STYLE

dash.register_page(__name__, path="/monitoring", name="Monitoring Perilaku Ekonomi")

kab_kota_list = get_kab_kota_list()
years = get_years_list()

layout = html.Div(
    [
        page_heading("Monitoring Perilaku Ekonomi", "Nilai nominal, pertumbuhan, kontribusi, dan indikator turunan PDRB"),
        dcc.Tabs(
            id="monitoring-tabs",
            className="custom-tabs",
            value="nominal",
            children=[
                dcc.Tab(label="Nilai Nominal", value="nominal", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Laju Pertumbuhan", value="pertumbuhan", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Kontribusi", value="kontribusi", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="PDRB Perkapita", value="perkapita", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Sumber Pertumbuhan", value="sog", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Indeks Implisit", value="implisit", className="tab", selected_className="tab--selected"),
            ],
        ),
        html.Div(id="monitoring-content", style={"marginTop": "20px"}),
    ]
)


@callback(Output("monitoring-content", "children"), Input("monitoring-tabs", "value"))
def render_tab(tab):
    if tab == "nominal":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Tahun", className="filter-label"),
                                dcc.Dropdown(
                                    id="nominal-tahun", options=years, value=max(years), clearable=False
                                ),
                            ],
                        )
                    ],
                ),
                card("PDRB ADHB vs ADHK per Kab/Kota", dcc.Graph(id="graf-nominal")),
            ]
        )
    elif tab == "pertumbuhan":
        return card("Laju Pertumbuhan Ekonomi per Kab/Kota (dengan garis referensi provinsi)", dcc.Graph(id="graf-pertumbuhan"))
    elif tab == "kontribusi":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Kab/Kota", className="filter-label"),
                                dcc.Dropdown(id="kontribusi-kk", options=kab_kota_list, value=kab_kota_list[0], clearable=False),
                            ],
                        ),
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Tahun", className="filter-label"),
                                dcc.Dropdown(id="kontribusi-tahun", options=years, value=max(years), clearable=False),
                            ],
                        ),
                    ],
                ),
                card("Kontribusi Lapangan Usaha terhadap PDRB", dcc.Graph(id="graf-kontribusi")),
            ]
        )
    elif tab == "perkapita":
        return card("PDRB Perkapita per Kab/Kota (Tahun Terbaru)", dcc.Graph(id="graf-perkapita"))
    elif tab == "sog":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Kab/Kota", className="filter-label"),
                                dcc.Dropdown(id="sog-kk", options=kab_kota_list, value=kab_kota_list[0], clearable=False),
                            ],
                        )
                    ],
                ),
                card("Sumber Pertumbuhan (SOG) per Lapangan Usaha", dcc.Graph(id="graf-sog")),
            ]
        )
    elif tab == "implisit":
        return html.Div(
            [
                html.Div(
                    className="filter-row",
                    children=[
                        html.Div(
                            className="filter-item",
                            children=[
                                html.Label("Kab/Kota", className="filter-label"),
                                dcc.Dropdown(id="implisit-kk", options=[PROVINSI_LABEL] + kab_kota_list, value=PROVINSI_LABEL, clearable=False),
                            ],
                        )
                    ],
                ),
                card("Indeks Implisit & Laju Indeks Implisit", dcc.Graph(id="graf-implisit")),
            ]
        )
    return html.Div()


# ---- Nilai Nominal ----
@callback(Output("graf-nominal", "figure"), Input("nominal-tahun", "value"))
def update_nominal(tahun):
    df = DATA["pdrb"]
    sub = df[(df["kab_kota"] != PROVINSI_LABEL) & (df["tahun"] == tahun)]
    sub = sub.groupby("kab_kota", as_index=False)[["adhb", "adhk"]].sum()
    fig = go.Figure()
    fig.add_bar(x=sub["kab_kota"], y=sub["adhb"], name="ADHB", marker_color=COLORS["primary"])
    fig.add_bar(x=sub["kab_kota"], y=sub["adhk"], name="ADHK", marker_color=COLORS["accent"])
    fig.update_layout(barmode="group", yaxis_title="Juta Rupiah")
    return fig


# ---- Laju Pertumbuhan ----
@callback(Output("graf-pertumbuhan", "figure"), Input("monitoring-tabs", "value"))
def update_pertumbuhan(_):
    growth_df = hitung_laju_pertumbuhan(DATA["pdrb"])
    prov_growth = growth_df[growth_df["kab_kota"] == PROVINSI_LABEL].dropna(subset=["laju_pertumbuhan"])
    kk_growth = growth_df[growth_df["kab_kota"] != PROVINSI_LABEL].dropna(subset=["laju_pertumbuhan"])

    fig = px.line(kk_growth, x="tahun", y="laju_pertumbuhan", color="kab_kota", markers=True)
    if not prov_growth.empty:
        fig.add_trace(
            go.Scatter(
                x=prov_growth["tahun"], y=prov_growth["laju_pertumbuhan"],
                mode="lines", name=f"Rata-rata {PROVINSI_LABEL}", line=REFERENCE_LINE_STYLE,
            )
        )
    fig.update_layout(yaxis_title="Laju Pertumbuhan (%)", xaxis_title="Tahun")
    return fig


# ---- Kontribusi ----
@callback(Output("graf-kontribusi", "figure"), Input("kontribusi-kk", "value"), Input("kontribusi-tahun", "value"))
def update_kontribusi(kk, tahun):
    df_kontribusi = hitung_kontribusi(DATA["pdrb"], kk, tahun)
    color_map = get_category_color_map(df_kontribusi["lapangan_usaha"].tolist())
    fig = px.pie(
        df_kontribusi, names="lapangan_usaha", values="adhb", hole=0.45,
        color="lapangan_usaha", color_discrete_map=color_map,
    )
    fig.update_traces(textposition="inside", textinfo="percent")
    return fig


# ---- PDRB Perkapita ----
@callback(Output("graf-perkapita", "figure"), Input("monitoring-tabs", "value"))
def update_perkapita(_):
    df_perkapita = hitung_pdrb_perkapita(DATA["pdrb"], DATA["penduduk"])
    latest = df_perkapita["tahun"].max()
    sub = df_perkapita[(df_perkapita["kab_kota"] != PROVINSI_LABEL) & (df_perkapita["tahun"] == latest)].sort_values(
        "pdrb_perkapita"
    )
    ref_val = df_perkapita[(df_perkapita["kab_kota"] == PROVINSI_LABEL) & (df_perkapita["tahun"] == latest)][
        "pdrb_perkapita"
    ]
    fig = px.bar(sub, x="kab_kota", y="pdrb_perkapita", labels={"pdrb_perkapita": "PDRB Perkapita (juta Rp/jiwa)"})
    fig.update_traces(marker_color=COLORS["primary"])
    if not ref_val.empty:
        fig.add_hline(y=ref_val.iloc[0], line=REFERENCE_LINE_STYLE, annotation_text=f"Rata-rata {PROVINSI_LABEL}")
    return fig


# ---- Sumber Pertumbuhan ----
@callback(Output("graf-sog", "figure"), Input("sog-kk", "value"))
def update_sog(kk):
    df_sog = hitung_sumber_pertumbuhan(DATA["pdrb"], kk)
    color_map = get_category_color_map(df_sog["lapangan_usaha"].unique().tolist())
    fig = px.bar(
        df_sog, x="tahun", y="sog", color="lapangan_usaha", color_discrete_map=color_map,
        labels={"sog": "Sumber Pertumbuhan (%)"},
    )
    fig.update_layout(barmode="relative")
    return fig


# ---- Indeks Implisit ----
@callback(Output("graf-implisit", "figure"), Input("implisit-kk", "value"))
def update_implisit(kk):
    df_impl = hitung_indeks_implisit(DATA["pdrb"], kk)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df_impl["tahun"], y=df_impl["indeks_implisit"], mode="lines+markers", name="Indeks Implisit", line=dict(color=COLORS["primary"])))
    fig.add_trace(go.Scatter(x=df_impl["tahun"], y=df_impl["laju_indeks_implisit"], mode="lines+markers", name="Laju Indeks Implisit (%)", line=dict(color=COLORS["accent"]), yaxis="y2"))
    fig.update_layout(
        yaxis=dict(title="Indeks Implisit"),
        yaxis2=dict(title="Laju (%)", overlaying="y", side="right"),
    )
    return fig
