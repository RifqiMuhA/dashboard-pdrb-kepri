import dash
from dash import html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go

from utils.data_loader import DATA, PROVINSI_LABEL
from utils.analysis import (
    hitung_apc_aps,
    hitung_rpi,
    hitung_icor,
    hitung_ilor_elastisitas,
    hitung_tax_ratio,
)
from utils.components import card, page_heading
from theme import COLORS

dash.register_page(__name__, path="/makro", name="Analisis Makro Ekonomi")

layout = html.Div(
    [
        page_heading("Analisis Makro Ekonomi", f"Level {PROVINSI_LABEL} — komponen pengeluaran umumnya tidak tersedia per kab/kota"),
        dcc.Tabs(
            id="makro-tabs",
            className="custom-tabs",
            value="konsumsi",
            children=[
                dcc.Tab(label="Konsumsi RT (APC/APS)", value="konsumsi", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="RPI", value="rpi", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="ICOR", value="icor", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="ILOR & Elastisitas TK", value="ilor", className="tab", selected_className="tab--selected"),
                dcc.Tab(label="Tax Ratio", value="tax", className="tab", selected_className="tab--selected"),
            ],
        ),
        html.Div(id="makro-content", style={"marginTop": "20px"}),
    ]
)


@callback(Output("makro-content", "children"), Input("makro-tabs", "value"))
def render_tab(tab):
    mapping = {
        "konsumsi": ("APC (Average Propensity to Consume) & APS (Average Propensity to Save)", "graf-apc"),
        "rpi": ("Rasio Perdagangan Internasional (RPI)", "graf-rpi"),
        "icor": ("Incremental Capital Output Ratio (ICOR)", "graf-icor"),
        "ilor": ("ILOR & Elastisitas Tenaga Kerja per Lapangan Usaha", "graf-ilor"),
        "tax": ("Tax Ratio", "graf-tax"),
    }
    title, graph_id = mapping[tab]
    return card(title, dcc.Graph(id=graph_id))


@callback(Output("graf-apc", "figure"), Input("makro-tabs", "value"))
def update_apc(_):
    df = hitung_apc_aps(DATA["pengeluaran_provinsi"])
    fig = go.Figure()
    fig.add_bar(x=df["tahun"], y=df["apc"], name="APC", marker_color=COLORS["primary"])
    fig.add_bar(x=df["tahun"], y=df["aps"], name="APS", marker_color=COLORS["accent"])
    fig.update_layout(barmode="stack", yaxis_title="Proporsi")
    return fig


@callback(Output("graf-rpi", "figure"), Input("makro-tabs", "value"))
def update_rpi(_):
    df = hitung_rpi(DATA["pengeluaran_provinsi"])
    fig = px.line(df, x="tahun", y="rpi", markers=True)
    fig.update_traces(line_color=COLORS["primary"])
    fig.add_hline(y=0, line_dash="dot", line_color=COLORS["gray_mid"])
    fig.update_layout(yaxis_title="RPI (-1 s/d 1)", yaxis_range=[-1, 1])
    return fig


@callback(Output("graf-icor", "figure"), Input("makro-tabs", "value"))
def update_icor(_):
    df = hitung_icor(DATA["pdrb"], DATA["pengeluaran_provinsi"], PROVINSI_LABEL)
    fig = px.bar(df, x="tahun", y="icor")
    fig.update_traces(marker_color=COLORS["primary"])
    return fig


@callback(Output("graf-ilor", "figure"), Input("makro-tabs", "value"))
def update_ilor(_):
    df = hitung_ilor_elastisitas(DATA["tenaga_kerja_provinsi"], DATA["pdrb"], PROVINSI_LABEL)
    fig = go.Figure()
    fig.add_bar(x=df["lapangan_usaha"], y=df["ilor"], name="ILOR", marker_color=COLORS["primary"])
    fig.add_bar(x=df["lapangan_usaha"], y=df["elastisitas_tk"], name="Elastisitas TK", marker_color=COLORS["accent"])
    fig.update_layout(barmode="group")
    return fig


@callback(Output("graf-tax", "figure"), Input("makro-tabs", "value"))
def update_tax(_):
    df = hitung_tax_ratio(DATA["pajak_provinsi"], DATA["pdrb"], PROVINSI_LABEL)
    fig = px.line(df, x="tahun", y="tax_ratio", markers=True)
    fig.update_traces(line_color=COLORS["primary"])
    fig.update_layout(yaxis_title="Tax Ratio (%)")
    return fig
