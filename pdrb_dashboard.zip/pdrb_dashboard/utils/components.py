from dash import html, dcc

MENU_ITEMS = [
    {"label": "Beranda", "path": "/"},
    {"label": "Monitoring Perilaku Ekonomi", "path": "/monitoring"},
    {"label": "Analisis Antar Wilayah", "path": "/wilayah"},
    {"label": "Analisis Makro Ekonomi", "path": "/makro"},
    {"label": "Data Explorer", "path": "/explorer"},
]


def build_header(title: str = "Dashboard Analisis PDB/PDRB"):
    return html.Div(
        className="app-header",
        children=[
            html.H1(title),
        ],
    )


def build_sidebar(current_path: str = "/"):
    links = []
    for item in MENU_ITEMS:
        is_active = current_path == item["path"]
        links.append(
            dcc.Link(
                item["label"],
                href=item["path"],
                className="sidebar-link" + (" active" if is_active else ""),
            )
        )
    return html.Div(className="sidebar", children=links)


def kpi_card(label: str, value: str):
    return html.Div(
        className="kpi-card",
        children=[
            html.Div(value, className="kpi-value"),
            html.Div(label, className="kpi-label"),
        ],
    )


def card(title: str, children):
    content = [html.Div(title, className="card-title")] if title else []
    content.append(children)
    return html.Div(className="card-box", children=content)


def page_heading(title: str, subtitle: str = ""):
    els = [html.Div(title, className="page-title")]
    if subtitle:
        els.append(html.Div(subtitle, className="page-subtitle"))
    return html.Div(els)
